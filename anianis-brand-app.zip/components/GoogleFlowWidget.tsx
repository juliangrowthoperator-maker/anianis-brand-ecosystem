'use client';
import { useState } from 'react';
import { Sparkles } from 'lucide-react';

export default function GoogleFlowWidget() {
  const [prompt, setPrompt] = useState('Vestido de seda amarillo al viento en un atardecer dorado, luz cinematográfica, tonos cálidos y orgánicos');
  const [loading, setLoading] = useState(false);
  const [resultImage, setResultImage] = useState<string | null>('https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=1000&q=80');

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/flow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (data.imageUrl || data.mockImageUrl) {
        setResultImage(data.imageUrl || data.mockImageUrl);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#F5EBE6] p-6 rounded-2xl border border-[#D8A47F]/30 space-y-4">
      <div className="flex justify-between items-center border-b border-[#D8A47F]/20 pb-4">
        <div className="flex items-center space-x-2">
          <Sparkles className="text-[#F4D06F]" size={20} />
          <h3 className="font-serif text-lg font-bold text-[#1F1A17]">Generador de Moodboard (Google Flow / Imagen AI)</h3>
        </div>
        <span className="text-xs bg-[#F4D06F]/40 text-[#1F1A17] px-2.5 py-1 rounded-full font-medium">
          API Ready
        </span>
      </div>

      <div className="space-y-3">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="w-full p-3 rounded-xl border border-[#D8A47F]/40 bg-white text-xs text-[#1F1A17] focus:ring-2 focus:ring-[#F4D06F] outline-none resize-none"
          rows={2}
          placeholder="Escribe la idea de imagen a generar..."
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full bg-[#1F1A17] hover:bg-[#4A3B32] text-white text-xs font-medium py-2.5 rounded-xl transition-all flex items-center justify-center space-x-2 shadow-sm"
        >
          {loading ? <span>Generando visual...</span> : (
            <>
              <Sparkles size={14} className="text-[#F4D06F]" />
              <span>Generar Concepto de Imagen</span>
            </>
          )}
        </button>
      </div>

      {resultImage && (
        <div className="rounded-xl overflow-hidden border border-[#D8A47F]/30 shadow-sm mt-4 relative group">
          <img src={resultImage} alt="Resultado IA" className="w-full h-56 object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
            <p className="text-xs text-white/90 italic">Visual de referencia generado para la cosmovisión de Anianis</p>
          </div>
        </div>
      )}
    </div>
  );
}
