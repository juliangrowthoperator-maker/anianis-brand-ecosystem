'use client';
import { useEffect, useState } from 'react';
import { Pin } from 'lucide-react';

export default function PinterestWidget() {
  const [pins, setPins] = useState<any[]>([]);
  const [configured, setConfigured] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch('/api/pinterest')
      .then(res => res.json())
      .then(data => {
        setPins(data.pins || []);
        setConfigured(data.configured);
        if (data.message) setMessage(data.message);
      })
      .catch(() => setMessage('Error cargando Pinterest'));
  }, []);

  return (
    <div className="bg-[#F5EBE6] p-6 rounded-2xl border border-[#D8A47F]/30 space-y-4">
      <div className="flex justify-between items-center border-b border-[#D8A47F]/20 pb-4">
        <div className="flex items-center space-x-2">
          <Pin className="text-[#D8A47F]" size={20} />
          <h3 className="font-serif text-lg font-bold text-[#1F1A17]">Tablero de Inspiración (Pinterest)</h3>
        </div>
        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${configured ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
          {configured ? 'API Conectada' : 'Modo Vista Previa / API Lista'}
        </span>
      </div>

      {message && <p className="text-xs text-[#4A3B32]/70 italic">{message}</p>}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {pins.map((pin) => (
          <div key={pin.id} className="group relative rounded-xl overflow-hidden bg-white shadow-sm border border-[#D8A47F]/20">
            <img src={pin.image} alt={pin.title} className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-500" />
            <div className="p-3 bg-white">
              <p className="text-xs font-medium text-[#1F1A17] truncate">{pin.title}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
