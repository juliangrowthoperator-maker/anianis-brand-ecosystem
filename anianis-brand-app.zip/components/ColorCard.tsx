'use client';
import { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface ColorProps {
  hex: string;
  name: string;
  role: string;
  concept: string;
  marketing: string;
  editing: string;
}

export default function ColorCard({ hex, name, role, concept, marketing, editing }: ColorProps) {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(hex);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-2xl overflow-hidden border border-[#D8A47F]/30 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col">
      <div 
        className="h-32 w-full relative group cursor-pointer flex items-end p-4 transition-transform duration-300"
        style={{ backgroundColor: hex }}
        onClick={copyToClipboard}
      >
        <button className="absolute top-3 right-3 bg-black/20 hover:bg-black/40 backdrop-blur-md text-white p-2 rounded-lg transition-all opacity-90 group-hover:opacity-100">
          {copied ? <Check size={16} className="text-green-300" /> : <Copy size={16} />}
        </button>
        <span className="text-xs font-mono font-bold bg-white/90 text-[#1F1A17] px-2.5 py-1 rounded-md backdrop-blur-sm shadow-sm">
          {hex}
        </span>
      </div>
      
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs uppercase tracking-wider font-semibold text-[#D8A47F]">{role}</span>
          </div>
          <h3 className="font-serif font-bold text-lg text-[#1F1A17] mb-2">{name}</h3>
          <p className="text-xs text-[#4A3B32]/70 italic mb-4">{concept}</p>
        </div>

        <div className="space-y-3 pt-3 border-t border-[#F5EBE6] text-xs">
          <div>
            <span className="font-semibold text-[#1F1A17] block mb-0.5">📱 Marketing & Historias:</span>
            <p className="text-[#4A3B32]/80 leading-relaxed">{marketing}</p>
          </div>
          <div>
            <span className="font-semibold text-[#1F1A17] block mb-0.5">🎬 Edición & Vídeo (Reels/Osmo):</span>
            <p className="text-[#4A3B32]/80 leading-relaxed">{editing}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
