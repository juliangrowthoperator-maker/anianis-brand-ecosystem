# Anianis - Ecosistema Creativo & Marca Personal (App Web)

Aplicación Web interactiva construida con **Next.js 14 (App Router)** y **Tailwind CSS** para gestionar y consultar todo el marco de identidad visual, la cosmovisión, los pilares de marca, el manual de colores de marketing y las integraciones con **Pinterest** y **Google Flow**.

## 🚀 Despliegue Directo en Vercel

1. Sube este repositorio a tu cuenta de GitHub.
2. Ve a [Vercel.com](https://vercel.com) e importa este repositorio.
3. Haz clic en **Deploy**. ¡Listo! Tendrás la App Web online con su dominio privado en segundos.

## 🔑 Configuración de APIs (Opcional en `.env.local`)

Para activar la sincronización en vivo con Pinterest y Google Flow, añade las siguientes variables de entorno en el panel de Vercel o en tu archivo local `.env.local`:

```env
# Pinterest API
PINTEREST_ACCESS_TOKEN=tu_access_token_de_pinterest
PINTEREST_BOARD_ID=tu_board_id_de_pinterest

# Google Flow / Imagen API
GOOGLE_FLOW_API_KEY=tu_google_api_key
```

## 🎨 Paleta de Colores Incluida
- `#F4D06F` - Amarillo Seda / Atardecer
- `#FBF9F4` - Blanco Pluma / Marfil Suave
- `#4A3B32` - Tierra Mojada / Roble
- `#5E715B` - Verde Lago / Musgo
- `#F5EBE6` - Arena Cálida / Lino Suave
- `#D8A47F` - Rosa Rocío / Terracota Suave
- `#1F1A17` - Negro Carbón / Sombra Suave
