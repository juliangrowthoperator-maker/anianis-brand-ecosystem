import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Anianis | Ecosistema Creativo & Marca Personal',
  description: 'Manual de Identidad, Cosmovisión, Ecosistema Visual y Conectores de Medios',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..700;1,400..700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="antialiased min-h-screen selection:bg-[#F4D06F] selection:text-[#1F1A17]">
        {children}
      </body>
    </html>
  );
}
