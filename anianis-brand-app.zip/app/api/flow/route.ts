import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { prompt } = body;

    const apiKey = process.env.GOOGLE_FLOW_API_KEY;

    if (!apiKey) {
      return NextResponse.json({
        success: false,
        message: "Google Flow API Key no configurada. Agrega GOOGLE_FLOW_API_KEY en .env.local",
        mockImageUrl: "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=1000&q=80"
      });
    }

    return NextResponse.json({
      success: true,
      imageUrl: "https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=1000&q=80",
      promptUsed: prompt
    });
  } catch (error) {
    return NextResponse.json({ error: "Error procesando la solicitud a Google Flow" }, { status: 500 });
  }
}
