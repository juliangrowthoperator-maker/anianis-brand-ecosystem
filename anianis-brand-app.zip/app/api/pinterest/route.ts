import { NextResponse } from 'next/server';

export async function GET() {
  const accessToken = process.env.PINTEREST_ACCESS_TOKEN;
  const boardId = process.env.PINTEREST_BOARD_ID;

  if (!accessToken || !boardId) {
    return NextResponse.json({
      configured: false,
      message: "Credenciales de Pinterest no encontradas. Configura PINTEREST_ACCESS_TOKEN y PINTEREST_BOARD_ID en .env.local",
      pins: [
        { id: '1', title: 'Atardecer Dorado & Seda', image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80' },
        { id: '2', title: 'Plumas Blancas & Cisne', image: 'https://images.unsplash.com/photo-1555169062-013468b47731?auto=format&fit=crop&w=600&q=80' },
        { id: '3', title: 'Manualidades Vintage & Poesía', image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=600&q=80' }
      ]
    });
  }

  try {
    const res = await fetch(`https://api.pinterest.com/v5/boards/${boardId}/pins`, {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    const data = await res.json();
    return NextResponse.json({ configured: true, pins: data.items });
  } catch (err) {
    return NextResponse.json({ error: "Error conectando con Pinterest API" }, { status: 500 });
  }
}
