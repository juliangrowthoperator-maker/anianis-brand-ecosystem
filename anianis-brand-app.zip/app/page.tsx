import ColorCard from '@/components/ColorCard';
import PinterestWidget from '@/components/PinterestWidget';
import GoogleFlowWidget from '@/components/GoogleFlowWidget';
import { Heart, Feather, Compass, Camera, Volume2 } from 'lucide-react';

const colorsData = [
  {
    hex: '#F4D06F',
    name: 'Amarillo Seda / Atardecer',
    role: 'Acento Emocional',
    concept: 'Representa la alegría espontánea, la luz del atardecer y el vestido de seda al viento.',
    marketing: 'Color de acento emocional principal. Ideal para llamados a la acción (CTAs), botones interactivos y encuestas en historias.',
    editing: 'Colorear las palabras clave principales dentro de los subtítulos dinámicos de Reels para maximizar la retención.'
  },
  {
    hex: '#FBF9F4',
    name: 'Blanco Pluma / Marfil Suave',
    role: 'Lienzo de Paz',
    concept: 'Representa la paz, la elegancia limpia y la protección suave de las plumas del cisne.',
    marketing: 'Fondo principal para plantillas estáticas, carruseles de lectura y placas informativas sin fatiga visual.',
    editing: 'Fondo para gráficos insertados en pantalla, marcos de portadas y márgenes estéticos. Evita el blanco puro.'
  },
  {
    hex: '#4A3B32',
    name: 'Tierra Mojada / Roble',
    role: 'Estructura & Cuerpo',
    concept: 'Representa la firmeza, la estructura, la familia y el aroma a tierra mojada tras la lluvia.',
    marketing: 'Color principal para cuerpos de texto, párrafos largos y descripciones sobre fondos claros.',
    editing: 'Subtítulos secundarios en explicaciones profundas, aportando peso visual y un tono muy artesanal.'
  },
  {
    hex: '#5E715B',
    name: 'Verde Lago / Musgo',
    role: 'Respiro Orgánico',
    concept: 'Representa la expedición a la montaña, la vegetación viva y el agua serena del lago.',
    marketing: 'Fondo para historias secundarias, citas inspiradoras y separación de temáticas dentro de carruseles.',
    editing: 'Detalles gráficos, resaltador de categorías e iconos ambientales.'
  },
  {
    hex: '#F5EBE6',
    name: 'Arena Cálida / Lino Suave',
    role: 'Comodín Táctil',
    concept: 'Textura del lino artesanal, hojas de libros antiguos y rocío mañanero.',
    marketing: 'Fondo secundario comodín para alternar diapositivas en carruseles o tarjetas flotantes de texto.',
    editing: 'Cajas de subtítulos suaves sobre fondos en movimiento para garantizar una lectura impecable.'
  },
  {
    hex: '#D8A47F',
    name: 'Rosa Rocío / Terracota Suave',
    role: 'Toque Íntimo',
    concept: 'Representa el calor cercano, la ternura del amor y los detalles poéticos.',
    marketing: 'Pequeños detalles visuales, iconos, subrayados sutiles, marcos decorativos y fechas.',
    editing: 'Viñetas, acentos visuales y delicadeza gráfica en las portadas de Reels.'
  },
  {
    hex: '#1F1A17',
    name: 'Negro Carbón / Sombra Suave',
    role: 'Contraste Profundo',
    concept: 'La sombra protectora, el contraste elegante y la autoridad serena.',
    marketing: 'Titulares principales de alto impacto y cabeceras de posts para una lectura rápida.',
    editing: 'Texto principal de subtítulos en Reels sobre fondos claros o de naturaleza en exteriores.'
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[#FBF9F4] text-[#4A3B32] font-sans">
      
      {/* Top Bar Banner */}
      <div className="bg-[#1F1A17] text-[#FBF9F4] text-xs py-2 px-6 flex justify-between items-center border-b border-[#D8A47F]/30">
        <span className="tracking-widest uppercase font-semibold text-[#F4D06F]">App Web Privada & Manuel de Marca</span>
        <span className="text-[#FBF9F4]/70">Growth Operator: Julián Cuartas</span>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12 space-y-16">
        
        {/* Header Section */}
        <header className="text-center space-y-4 max-w-2xl mx-auto">
          <div className="inline-flex items-center space-x-2 bg-[#F5EBE6] border border-[#D8A47F]/30 px-4 py-1.5 rounded-full text-xs font-medium text-[#D8A47F]">
            <Feather size={14} />
            <span>Cosmovisión & Identidad de Marca</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-serif text-[#1F1A17] tracking-tight">Anianis</h1>
          <p className="text-sm md:text-base text-[#4A3B32]/80 font-serif italic">
            "Poesía orgánica, elegancia protegida y creatividad terrenal."
          </p>
        </header>

        {/* Valores Generales & Ejes de Personalidad */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          <div className="bg-white p-8 rounded-3xl border border-[#D8A47F]/30 shadow-sm space-y-6">
            <h2 className="text-2xl font-serif text-[#1F1A17] flex items-center space-x-2">
              <Compass className="text-[#D8A47F]" size={22} />
              <span>Valores Generales & Principios</span>
            </h2>
            <div className="space-y-4 text-xs">
              <div className="p-3 bg-[#F5EBE6]/60 rounded-xl border border-[#D8A47F]/20">
                <strong className="text-[#1F1A17] block text-sm mb-0.5">1. CREATIVIDAD</strong>
                <p className="text-[#4A3B32]/80">Fuerza expresiva artesanal, poética, manual e impulsada por el detalle.</p>
              </div>
              <div className="p-3 bg-[#F5EBE6]/60 rounded-xl border border-[#D8A47F]/20">
                <strong className="text-[#1F1A17] block text-sm mb-0.5">2. FEMINIDAD</strong>
                <p className="text-[#4A3B32]/80">Elegancia, paz, protección suave y solidez interna innegociable.</p>
              </div>
              <div className="p-3 bg-[#F5EBE6]/60 rounded-xl border border-[#D8A47F]/20">
                <strong className="text-[#1F1A17] block text-sm mb-0.5">3. FE</strong>
                <p className="text-[#4A3B32]/80">El fundamento espiritual y la mirada contemplativa ante la vida.</p>
              </div>
              <div className="p-3 bg-[#F5EBE6]/60 rounded-xl border border-[#D8A47F]/20">
                <strong className="text-[#1F1A17] block text-sm mb-0.5">4. FAMILIA & 5. AMOR</strong>
                <p className="text-[#4A3B32]/80">El núcleo de calor, cercanía y la intención profunda detrás de cada recuerdo guardado.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-[#D8A47F]/30 shadow-sm space-y-6">
            <h2 className="text-2xl font-serif text-[#1F1A17] flex items-center space-x-2">
              <Heart className="text-[#D8A47F]" size={22} />
              <span>Los 3 Pilares Principales</span>
            </h2>
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-[#FBF9F4] rounded-2xl border border-[#D8A47F]/30">
                <span className="text-xs font-bold text-[#D8A47F] uppercase tracking-wider block mb-1">Pilar 1</span>
                <h3 className="text-base font-serif font-bold text-[#1F1A17] mb-1">Feminidad del Cisne</h3>
                <p className="text-[#4A3B32]/80 leading-relaxed">
                  Elegante, pudorosa, llena de paz y tranquila. Sus plumas blancas suaves entregan calor a sus crías, pero dejando claro que no es un juguete con el que cualquiera pueda meterse.
                </p>
              </div>
              <div className="p-4 bg-[#FBF9F4] rounded-2xl border border-[#D8A47F]/30">
                <span className="text-xs font-bold text-[#D8A47F] uppercase tracking-wider block mb-1">Pilar 2</span>
                <h3 className="text-base font-serif font-bold text-[#1F1A17] mb-1">Alegría Inocente & Espontánea</h3>
                <p className="text-[#4A3B32]/80 leading-relaxed">
                  Prudente, colorida y llena de vida. Se siente como la emoción pura de un bebé al mirar a su madre a los ojos: ríe, se esconde y hace caras graciosas sin contener la emoción.
                </p>
              </div>
              <div className="p-4 bg-[#FBF9F4] rounded-2xl border border-[#D8A47F]/30">
                <span className="text-xs font-bold text-[#D8A47F] uppercase tracking-wider block mb-1">Pilar 3</span>
                <h3 className="text-base font-serif font-bold text-[#1F1A17] mb-1">Creatividad Orgánica & Poética</h3>
                <p className="text-[#4A3B32]/80 leading-relaxed">
                  Libros de poesía, cuentos infantiles, manualidades vintage, canciones en guitarra, cámara en mano, atardeceres en la montaña y caminatas descalza con un vestido amarillo de seda al viento.
                </p>
              </div>
            </div>
          </div>

        </section>

        {/* Hardware & Producción Audiovisual */}
        <section className="bg-[#1F1A17] text-[#FBF9F4] p-8 md:p-10 rounded-3xl space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#D8A47F]/30 pb-6">
            <div>
              <span className="text-xs text-[#F4D06F] uppercase tracking-widest font-semibold">Configuración Técnica de Producción</span>
              <h2 className="text-2xl font-serif mt-1">Setup Cinematográfico: Osmo Pocket 4 & Lark M2</h2>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div className="flex items-start space-x-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <Camera className="text-[#F4D06F] shrink-0 mt-1" size={20} />
              <div>
                <h4 className="font-bold text-sm mb-1 text-white">Dirección de Cámara (Osmo Pocket 4)</h4>
                <p className="text-[#FBF9F4]/70 leading-relaxed">
                  Movimientos fluidos a ras de suelo, seguimiento de caminata descalza, tomas de detalle en manualidades y texturas de lino y papel. Priorizar la luz natural del atardecer.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3 bg-white/5 p-4 rounded-2xl border border-white/10">
              <Volume2 className="text-[#F4D06F] shrink-0 mt-1" size={20} />
              <div>
                <h4 className="font-bold text-sm mb-1 text-white">Diseño de Audio (Hollyland Lark M2)</h4>
                <p className="text-[#FBF9F4]/70 leading-relaxed">
                  Audio ASMR orgánico, voz hablada suave e íntima, sonido ambiental del viento y crujidos suaves de papel y tela sin ruido de fondo.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Paleta Oficial de Colores */}
        <section className="space-y-6">
          <div className="flex justify-between items-end">
            <div>
              <span className="text-xs uppercase tracking-widest font-semibold text-[#D8A47F]">Manual de Identidad Visual</span>
              <h2 className="text-3xl font-serif text-[#1F1A17]">Paleta Oficial de 7 Colores</h2>
            </div>
            <p className="text-xs text-[#4A3B32]/60 hidden md:block">Haz clic en el color para copiar el código HEX</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {colorsData.map((col, idx) => (
              <ColorCard key={idx} {...col} />
            ))}
          </div>
        </section>

        {/* Integraciones y Moodboards (Pinterest & Google Flow) */}
        <section className="space-y-8 pt-8 border-t border-[#D8A47F]/30">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-[#D8A47F]">Conectores de Medios</span>
            <h2 className="text-3xl font-serif text-[#1F1A17]">Inspiración en Tiempo Real & IA</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <PinterestWidget />
            <GoogleFlowWidget />
          </div>
        </section>

        {/* Footer */}
        <footer className="text-center pt-8 border-t border-[#D8A47F]/20 text-xs text-[#4A3B32]/60">
          <p>© 2026 Ecosistema de Marca Personal Anianis. Diseñado e implementado por Julián Cuartas (Growth Operator).</p>
        </footer>

      </div>
    </div>
  );
}
